Run disaster_tweet_classification.py to generate charts and model_results.csv.
